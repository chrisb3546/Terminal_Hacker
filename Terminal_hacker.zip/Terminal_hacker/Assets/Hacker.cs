﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hacker : MonoBehaviour
{
    int level;

    enum Screen {
        MainMenu, Password, Win
    }
    Screen currentScreen = Screen.MainMenu;
    // Start is called before the first frame update
    void Start()
    {
        ShowMainMenu();

    }

 

    void ShowMainMenu()
    {
        Terminal.ClearScreen();
        Terminal.WriteLine("Learning to code video games!");
        Terminal.WriteLine("Press 1 for the local library");
        Terminal.WriteLine("Press 2 for the Police Department");
        Terminal.WriteLine("Press 3 for Nasa");
        Terminal.WriteLine("Enter your selection: ");
    }


    void OnUserInput(string input)
    {
        if(input == "menu")
        {
            currentScreen = Screen.MainMenu;
            ShowMainMenu();
        }
        else if(currentScreen == Screen.MainMenu){
            RunMainMenu(input);
        }
       

    }

    void RunMainMenu(string input){
        if( input == "1") 
       {    
           level = 1;
           StartGame();
       }
       else if ( input == "2")
       {
           level = 2;
           StartGame();
       }
        else 
        {
            Terminal.WriteLine("Please make valid selection");
        }
    }

    void StartGame ()
    {
        currentScreen = Screen.Password;
        Terminal.WriteLine("You've chosen level" + level);
        Terminal.WriteLine("Please Enter Password: ");
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
